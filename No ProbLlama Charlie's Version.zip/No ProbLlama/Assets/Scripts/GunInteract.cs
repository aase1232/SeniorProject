﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GunInteract : Interactable {

    public bool hadFirstInteraction;

    public string[] dialogue;
    public string npcName;

    public static bool isHeldByPlayer;

    public float gunRotationAmount;

    public override void Interact()
    {
        foreach (Collider2D col in overlapCircle)
        {
            if (col.gameObject.tag == "Player" && !hadFirstInteraction)
            {

                Transform player = col.gameObject.transform;
                Transform playerRightArm = player.Find("PlayerRig").Find("RightArm");
                Vector3 gunPosition = playerRightArm.Find("Gun Position").position;
                hasInteracted = true;
                hadFirstInteraction = true;
                transform.position = gunPosition;
                transform.rotation = Quaternion.Euler(0f, 0f, gunRotationAmount);
                transform.parent = playerRightArm;
                isHeldByPlayer = transform.parent == playerRightArm;

            }
        }
        DialogueSystem.Instance.AddNewDialogue(dialogue, npcName);

    }
}
