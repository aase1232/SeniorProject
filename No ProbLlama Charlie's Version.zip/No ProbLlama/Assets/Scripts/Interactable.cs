﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Interactable : MonoBehaviour {

    public bool hasInteracted;

    public float radius;
    public LayerMask playerLayer;
    [SerializeField]
    public Collider2D[] overlapCircle;

    private void Start()
    {

    }

    private void Update()
    {
        overlapCircle = Physics2D.OverlapCircleAll(new Vector2(transform.position.x, transform.position.y), radius, playerLayer);
        foreach (Collider2D col in overlapCircle)
        {
            if (!hasInteracted)
            {
                Interact();
                hasInteracted = true;
            }
        }
    }

    public virtual void Interact()
    {

    }

}
