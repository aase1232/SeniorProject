﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PuzzleCompletionScript : MonoBehaviour {
    Color oldColor;
    Color newColor;
    double activationInterval = 1.0;
    // Use this for initialization
    void Start () {
        oldColor = gameObject.GetComponent<Renderer>().material.color;
        newColor = Color.blue;
    }

    private void OnCollisionEnter2D(Collision2D col)
    {
        if (col.gameObject.tag == "Player" && activationInterval < 0.0)
        {
            if (gameObject.GetComponent<Renderer>().material.color.Equals(oldColor))
                gameObject.GetComponent<Renderer>().material.color = Color.blue;
            else if (gameObject.GetComponent<Renderer>().material.color.Equals(newColor))
                gameObject.GetComponent<Renderer>().material.color = oldColor;

            activationInterval = 1.0;
        }
    }

    // Update is called once per frame
    void Update () {
        if(!(activationInterval < 0.0))
            activationInterval -= 0.9 * Time.deltaTime;
    }
}
