﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShrinkAndGrow : MonoBehaviour {


    public int currentCount, maxCount;
    public bool canShrink, canGrow;
    public float growAmount, shrinkAmount;
	// Use this for initialization
	void Start () {
        canShrink = true;
        canGrow = true;
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
