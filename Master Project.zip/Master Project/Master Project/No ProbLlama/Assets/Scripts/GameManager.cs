﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{

    public static GameManager instance;
    [HideInInspector] public Transform currentSpawnPoint, originalSpawnPoint, secondarySpawnPoint;
    private Transform player;

    [HideInInspector] public Room currentRoom, startingRoom;
    int roomPositionX;
    int roomPositionY;
    [HideInInspector] public Dimension currentDimension;
    [HideInInspector] public bool dimensionComplete;
    public Room[,] rooms;

    [HideInInspector] public bool finishedLoadingScene;
    [HideInInspector] public bool isChangingRoom = false;
    [HideInInspector] public bool dimensionChanged;
    [HideInInspector] public RoomChangeDirection roomChangeDirection = RoomChangeDirection.UP;

    GameObject topDoor, bottomDoor, leftDoor, rightDoor;

    LevelGeneration levelGeneration;

    [HideInInspector]
    public enum Dimension
    {
        DEFAULT,
        CHICKEN,
        SWAN
    }

    public enum RoomChangeDirection
    {
        RELOAD,
        UP,
        DOWN,
        LEFT,
        RIGHT
    }

    private void Awake()
    {

        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else if (instance != this)
        {
            Destroy(gameObject);
            return;
        }
        levelGeneration = GetComponent<LevelGeneration>();
        GetUpdatedObjectReferences();
        ResetPlayerPosition();
        EnableDoors();
    }

    public void GetStartingRoom()
    {
        levelGeneration.CreateRooms();
        rooms = levelGeneration.rooms;

        for (int x = 0; x < levelGeneration.halfGridSizeX * 2; x++)
        {
            for (int y = 0; y < levelGeneration.halfGridSizeY * 2; y++)
            {
                print(rooms[x, y] != null);
                if (rooms[x, y] != null && rooms[x, y].type == Room.RoomType.STARTING_ROOM)
                {
                    startingRoom = rooms[x, y];
                    currentRoom = startingRoom;
                    print(currentRoom.sceneForThisRoom);
                    roomPositionX = x;
                    roomPositionY = y;
                }
            }
        }
    }

    void Update()
    {
        CheckForInput();
        CheckSceneLoadStatus();
    }

    void CheckSceneLoadStatus()
    {
        if (SceneLoader.finishedLoadingScene)
        {
            SceneLoader.finishedLoadingScene = false;
            GetUpdatedObjectReferences();
            EnableDoors();
            SetUpDoorScenes();
            GetComponent<PuzzleCompletionScript>().AddDoors();
            ResetPlayerPosition();
            SetSpawnPoints();
        }
    }


    void ResetPlayerPosition()
    {
        if(currentRoom == null)
        {
            player.transform.position = originalSpawnPoint.position;
        }
        else
        {
            player.transform.position = currentRoom.isComplete ? secondarySpawnPoint.position : originalSpawnPoint.position;
        }
    }

    void GetUpdatedObjectReferences()
    {
        if(GameObject.Find("Spawn Point") != null)
        {
            originalSpawnPoint = GameObject.Find("Spawn Point").transform;
        }
        if(GameObject.Find("Secondary Spawn Point") != null)
        {
            secondarySpawnPoint = GameObject.Find("Secondary Spawn Point").transform;
        }
        player = GameObject.Find("Player").transform;

        if(GameObject.Find("Level Exits") != null)
        {
            topDoor = GameObject.Find("Level Exits").transform.Find("Top Door").Find("Door Frame").Find("Door Entrance").gameObject;
            bottomDoor = GameObject.Find("Level Exits").transform.Find("Bottom Door").Find("Door Frame").Find("Door Entrance").gameObject;
            leftDoor = GameObject.Find("Level Exits").transform.Find("Left Door").Find("Door Frame").Find("Door Entrance").gameObject;
            rightDoor = GameObject.Find("Level Exits").transform.Find("Right Door").Find("Door Frame").Find("Door Entrance").gameObject;
        }
    }

    void CheckForInput()
    {
        if (Input.GetButtonDown("Reset"))
        {
            SceneLoader.sceneToLoad = SceneManager.GetActiveScene().name;
            SceneLoader.loadScene = true;
        }
        if (Input.GetKeyDown(KeyCode.I) && currentRoom.isComplete && topDoor.activeInHierarchy)
        {
            player.transform.position = topDoor.transform.position;
        }
        if (Input.GetKeyDown(KeyCode.K) && currentRoom.isComplete && bottomDoor.activeInHierarchy)
        {
            player.transform.position = bottomDoor.transform.position;
        }
        if (Input.GetKeyDown(KeyCode.J) && currentRoom.isComplete && leftDoor.activeInHierarchy)
        {
            player.transform.position = leftDoor.transform.position;
        }
        if (Input.GetKeyDown(KeyCode.L) && currentRoom.isComplete && rightDoor.activeInHierarchy)
        {
            player.transform.position = rightDoor.transform.position;
        }

    }

    void SetUpDoorScenes()
    {
        print("started setting up door scenes");
        switch (roomChangeDirection)
        {
            case RoomChangeDirection.UP:
                currentRoom = rooms[roomPositionX, roomPositionY + 1];
                break;
            case RoomChangeDirection.DOWN:
                currentRoom = rooms[roomPositionX, roomPositionY - 1];
                break;
            case RoomChangeDirection.LEFT:
                currentRoom = rooms[roomPositionX - 1, roomPositionY];
                break;
            case RoomChangeDirection.RIGHT:
                currentRoom = rooms[roomPositionX + 1, roomPositionY];
                break;
            case RoomChangeDirection.RELOAD:
                break;
        }
        if(topDoor != null)
        {
            topDoor.GetComponent<LoadTrigger>().sceneToLoad = currentRoom.topDoorScene;
            print(topDoor.GetComponent<LoadTrigger>().sceneToLoad);
        }
        if(bottomDoor != null)
        {
            bottomDoor.GetComponent<LoadTrigger>().sceneToLoad = currentRoom.bottomDoorScene;
            print(bottomDoor.GetComponent<LoadTrigger>().sceneToLoad);
        }
        if (leftDoor != null)
        {
            leftDoor.GetComponent<LoadTrigger>().sceneToLoad = currentRoom.leftDoorScene;
            print(leftDoor.GetComponent<LoadTrigger>().sceneToLoad);
        }
        if (rightDoor != null)
        {
            rightDoor.GetComponent<LoadTrigger>().sceneToLoad = currentRoom.rightDoorScene;
            print(rightDoor.GetComponent<LoadTrigger>().sceneToLoad);
        }
    }

    void EnableDoors()
    {
        if(currentRoom != null)
        {
            print(currentRoom.doorBot + "doorbot");
            print(currentRoom.doorLeft + "doorleft");
            print(currentRoom.doorTop + "doortop");
            print(currentRoom.doorRight + "doorright");
        }
        if (GameObject.Find("Level Exits") != null && currentRoom != null && currentRoom.doorTop)
        {
            GameObject.Find("Level Exits").transform.Find("Top Door").gameObject.SetActive(true);
        }
        if (GameObject.Find("Level Exits") != null && currentRoom != null && currentRoom.doorBot)
        {
            GameObject.Find("Level Exits").transform.Find("Bottom Door").gameObject.SetActive(true);
        }
        if (GameObject.Find("Level Exits") != null && currentRoom != null && currentRoom.doorLeft)
        {
            GameObject.Find("Level Exits").transform.Find("Left Door").gameObject.SetActive(true);
        }
        if (GameObject.Find("Level Exits") != null && currentRoom != null && currentRoom.doorRight)
        {
            GameObject.Find("Level Exits").transform.Find("Right Door").gameObject.SetActive(true);
        }
    }

    void SetSpawnPoints()
    {
        currentRoom.currentSpawnPoint = currentRoom.isComplete ? secondarySpawnPoint : originalSpawnPoint;
    }

}
