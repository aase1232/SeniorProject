﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerHealth : MonoBehaviour {
    public int maxHealth;
    public int currentHealth;
    public Slider healthBar;
    public Image damageImage;
    //public AudioClip playerAudio;
    public float flashSpeed = 5f;
    public Color flashColor = new Color(1f, 0f, 0f, 0.1f);
    Animator anim;
    AudioSource audSource;
    bool dead;
    bool damaged;
    //Move move;

	// Use this for initialization
	void Start () {

	}

    private void Awake()
    {
        currentHealth = maxHealth;
        anim = GetComponent<Animator>();
        audSource = GetComponent<AudioSource>();
        //move = GetComponent<Move>();
        //move.enabled = true;
    }

    // Update is called once per frame
    void Update () {
		/*if(damaged)
        {
            damageImage.color = flashColor; // damage image initially appears in bright red
        }
        else
        {
            damageImage.color = Color.Lerp(damageImage.color, Color.clear, flashSpeed*Time.deltaTime); // damage image fades over a period of time
        }
        damaged = false;*/
	}

    public void takeDamage(int amount)
    {
        damaged = true;                  // damaged boolean set to true so Update() will show damage image
        currentHealth -= amount;         // Player's health is adjusted depending on damage
        healthBar.value = currentHealth; // Health value displayed by slider is changed to reflect damage taken
        // add damage noise here?
        if (currentHealth <= 0 && !dead) // check if player is dead
        {
            Death();
        }
    }

    private void Death()
    {
        //anim.SetTrigger("Die"); // death animation plays?
        // add death noise?
        //move.enabled = false;
    }
}
