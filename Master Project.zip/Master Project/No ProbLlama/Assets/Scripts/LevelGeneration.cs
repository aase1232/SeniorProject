﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LevelGeneration : MonoBehaviour {
	Vector2 worldSize = new Vector2(4,4);
	public Room[,] rooms;
	List<Vector2> takenPositions = new List<Vector2>();
    public static int halfGridSizeX, halfGridSizeY = 4;
    public int numberOfRooms = 20;
	public GameObject roomWhiteObj;
    public string[] chickenDimensionPuzzleScenes, swanDimensionPuzzleScenes;
    public string chickenDimensionBossScene, swanDimensionBossScene;
    public static int count = 0;
    public static bool canGenerateRooms = false;

    private static LevelGeneration instance;
	void Awake () {
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else if (instance != this)
        {
            Destroy(gameObject);
            return;
        }

    }

    private void Update()
    {
        

        if (canGenerateRooms)
        {
            canGenerateRooms = false;
            
            
            CreateRooms(); //lays out the actual map
             //assigns the doors where rooms would connect
            print("set room doors");
          DrawMap(); //instantiates objects to make up a map
        }
    }

    public void CreateRooms(){
        //setup

        if (numberOfRooms >= worldSize.x * worldSize.y)
        { // make sure we dont try to make more rooms than can fit in our grid
            numberOfRooms = Mathf.RoundToInt(worldSize.x * worldSize.y);
        }

        halfGridSizeX = Mathf.RoundToInt(worldSize.x); //note: these are half-extents
        halfGridSizeY = Mathf.RoundToInt(worldSize.y);
        takenPositions = new List<Vector2>();
		rooms = new Room[halfGridSizeX * 2, halfGridSizeY * 2];
		rooms[halfGridSizeX, halfGridSizeY] = new Room(Vector2.zero, Room.RoomType.STARTING_ROOM); //starting room in the center of the grid
		takenPositions.Insert(0,Vector2.zero);
		Vector2 checkPos = Vector2.zero;
		//magic numbers
		float randomCompare = 0.2f, randomCompareStart = 0.2f, randomCompareEnd = 0.01f;
		//add rooms
		for (int i = 0; i < numberOfRooms - 2; i++){
			float randomPerc = i / ((float)numberOfRooms - 1);
			randomCompare = Mathf.Lerp(randomCompareStart, randomCompareEnd, randomPerc);
			//grab new position
			checkPos = NewPosition();
			//test new position
			if (NumberOfNeighbors(checkPos, takenPositions) > 1 && Random.value > randomCompare){
				int iterations = 0;
				do{
					checkPos = SelectiveNewPosition();
					iterations++;
				}while(NumberOfNeighbors(checkPos, takenPositions) > 1 && iterations < 100);
				if (iterations >= 50)
					print("error: could not create with fewer neighbors than : " + NumberOfNeighbors(checkPos, takenPositions));
			}
			//finalize position
			rooms[(int)checkPos.x + halfGridSizeX, (int)checkPos.y + halfGridSizeY] = new Room(checkPos, Room.RoomType.RANDOM_PUZZLE);
            
            //insert into the list of taken positions
            takenPositions.Insert(0,checkPos);
		}
        while (NumberOfNeighbors(checkPos, takenPositions) != 1)
        {
            checkPos = SelectiveNewPosition();
        }
        if (NumberOfNeighbors(checkPos, takenPositions) == 1)
        {
            rooms[(int)checkPos.x + halfGridSizeX, (int)checkPos.y + halfGridSizeY] = new Room(checkPos, Room.RoomType.BOSS_ROOM);
        }

        SetRoomDoors(rooms);
    }

    public void SetRoomScene(Room room, Dimension currentDimension)
    {
        switch (currentDimension.dimensionType)
        {
            case Dimension.DimensionType.CHICKEN:
                switch (room.originalType)
                {
                    case Room.RoomType.STARTING_ROOM:
                        room.sceneForThisRoom = chickenDimensionPuzzleScenes[Mathf.RoundToInt(Random.value * (chickenDimensionPuzzleScenes.Length - 1))];
                        break;
                    case Room.RoomType.RANDOM_PUZZLE:
                        room.sceneForThisRoom = chickenDimensionPuzzleScenes[Mathf.RoundToInt(Random.value * (chickenDimensionPuzzleScenes.Length - 1))];
                        break;
                    case Room.RoomType.BOSS_ROOM:
                        room.sceneForThisRoom = chickenDimensionBossScene;
                        break;
                    default:
                        break;
                }
                break;
            case Dimension.DimensionType.SWAN:
                switch (room.originalType)
                {
                    case Room.RoomType.STARTING_ROOM:
                        room.sceneForThisRoom = swanDimensionPuzzleScenes[Mathf.RoundToInt(Random.value * (swanDimensionPuzzleScenes.Length - 1))];
                        break;
                    case Room.RoomType.RANDOM_PUZZLE:
                        room.sceneForThisRoom = swanDimensionPuzzleScenes[Mathf.RoundToInt(Random.value * (swanDimensionPuzzleScenes.Length - 1))];
                        break;
                    case Room.RoomType.BOSS_ROOM:
                        room.sceneForThisRoom = swanDimensionBossScene;
                        break;
                    default:
                        break;
                }
                break;
            case Dimension.DimensionType.DEFAULT:
                break;
            default:
                break;
        }
    }

    Vector2 NewPosition(){
		int x = 0, y = 0;
		Vector2 checkingPos = Vector2.zero;
        do {
            int index = Mathf.RoundToInt(Random.value * (takenPositions.Count - 1)); // pick a random room
            x = (int)takenPositions[index].x;//capture its x, y position
            y = (int)takenPositions[index].y;
            bool UpDown = (Random.value < 0.5f);//randomly pick whether to look on hor or vert axis
            bool positive = (Random.value < 0.5f);//pick whether to be positive or negative on that axis
            if (UpDown) { //find the position based on the above bools
                if (positive) {
                    y += 1;
                } else {
                    y -= 1;
                }
            } else {
                if (positive) {
                    x += 1;
                } else {
                    x -= 1;
                }
            }
            checkingPos = new Vector2(x, y);
        } while (PositionIsValid(takenPositions, x, y)); //make sure the position is valid

		return checkingPos;
	}

    bool PositionIsValid(List<Vector2> takenPositions, int x, int y)
    {
        return (takenPositions.Contains(new Vector2(x, y))
            || x >= halfGridSizeX
            || x < -halfGridSizeX
            || y >= halfGridSizeY
            || y < -halfGridSizeY);
    }

	Vector2 SelectiveNewPosition(){ // method differs from the above in the two commented ways
		int index = 0, inc = 0;
		int x =0, y =0;
		Vector2 checkingPos = Vector2.zero;
		do{
			inc = 0;
			do{ 
				//instead of getting a room to find an adject empty space, we start with one that only 
				//has one neighbor. This will make it more likely that it returns a room that branches out
				index = Mathf.RoundToInt(Random.value * (takenPositions.Count - 1));
				inc ++;
			}while (NumberOfNeighbors(takenPositions[index], takenPositions) > 1 && inc < 100);
			x = (int) takenPositions[index].x;
			y = (int) takenPositions[index].y;
			bool UpDown = (Random.value < 0.5f);
			bool positive = (Random.value < 0.5f);
			if (UpDown){
				if (positive){
					y += 1;
				}else{
					y -= 1;
				}
			}else{
				if (positive){
					x += 1;
				}else{
					x -= 1;
				}
			}
			checkingPos = new Vector2(x,y);
		}while (PositionIsValid(takenPositions, x, y));
		if (inc >= 100){ // break loop if it takes too long: this loop isnt guaranteed to find a solution, which is fine for this
			print("Error: could not find position with only one neighbor");
		}
		return checkingPos;
	}

	int NumberOfNeighbors(Vector2 checkingPos, List<Vector2> usedPositions){
		int numberOfNeighbors = 0; // start at zero, add 1 for each side there is already a room

        
        if (usedPositions.Contains(checkingPos + Vector2.right))
        { //using Vector.[direction] as short-hand, for simplicity
            numberOfNeighbors++;
        }
        if (usedPositions.Contains(checkingPos + Vector2.left))
        {
            numberOfNeighbors++;
        }
        if (usedPositions.Contains(checkingPos + Vector2.up))
        {
            numberOfNeighbors++;
        }
        if (usedPositions.Contains(checkingPos + Vector2.down))
        {
            numberOfNeighbors++;
        }
        
        return numberOfNeighbors;
	}
    
	public void DrawMap(){
		foreach (Room room in GameManager.instance.currentDimension.rooms){
			if (room == null){
				continue; //skip where there is no room
			}
			Vector2 drawPos = room.gridPos;
			drawPos.x *= 16;//aspect ratio of map sprite
			drawPos.y *= 8;
			//create map obj and assign its variables
			MapSpriteSelector mapper = Instantiate(roomWhiteObj, new Vector2(drawPos.x + 100, drawPos.y + 100), Quaternion.identity).GetComponent<MapSpriteSelector>();
			mapper.type = room.currentType;
			mapper.up = room.doorTop;
			mapper.down = room.doorBot;
			mapper.right = room.doorRight;
			mapper.left = room.doorLeft;
		}
	}

	public void SetRoomDoors(Room[,] rooms){
        
        for (int x = 0; x < halfGridSizeX * 2; x++){
			for (int y = 0; y < halfGridSizeY * 2; y++){
				if (rooms[x,y] == null){
					continue;
				}

				if (y - 1 < 0){ //check above
					rooms[x,y].doorBot = false;
				}else{
					rooms[x,y].doorBot = (rooms[x,y-1] != null);
                    if (rooms[x,y].doorBot)
                    {
                        rooms[x, y].bottomDoorScene = rooms[x, y - 1].sceneForThisRoom;
                    }
				}
				if (y + 1 >= halfGridSizeY * 2){ //check below
					rooms[x,y].doorTop = false;
				}else{
					rooms[x,y].doorTop = (rooms[x,y+1] != null);
                    if (rooms[x, y].doorTop){
                        rooms[x, y].topDoorScene = rooms[x, y + 1].sceneForThisRoom;
                    }
                }
				if (x - 1 < 0){ //check left
					rooms[x,y].doorLeft = false;
				}else{
					rooms[x,y].doorLeft = (rooms[x - 1,y] != null);
                    if (rooms[x, y].doorLeft)
                    {
                        rooms[x, y].leftDoorScene = rooms[x-1, y].sceneForThisRoom;
                    }
                }
				if (x + 1 >= halfGridSizeX * 2){ //check right
					rooms[x,y].doorRight = false;
				}else{
					rooms[x,y].doorRight = (rooms[x+1,y] != null);
                    if (rooms[x, y].doorRight)
                    {
                        rooms[x, y].rightDoorScene = rooms[x+1, y].sceneForThisRoom;
                    }
                }
			}
		}
	}
}
