﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DoorInteract : Interactable {

	
    public override void Interact()
    {
        SceneLoader.sceneToLoad = GetComponent<LoadTrigger>().sceneToLoad;
        SceneLoader.loadScene = true;
    }
}
