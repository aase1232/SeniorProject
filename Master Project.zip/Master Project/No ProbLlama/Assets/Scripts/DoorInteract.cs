﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DoorInteract : Interactable {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    public override void Interact()
    {
        if(overlapCircle.Length > 0)
        {
            SceneLoader.sceneToLoad = GetComponent<LoadTrigger>().sceneToLoad;
            SceneLoader.loadScene = true;
        }
        base.Interact();
    }
}
