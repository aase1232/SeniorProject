﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{

    public static GameManager instance;
    [HideInInspector] private Transform originalSpawnPoint, secondarySpawnPoint;
    private Transform player;

    [HideInInspector] public Room currentRoom, startingRoom;
    int roomPositionX;
    int roomPositionY;
    [HideInInspector] public bool dimensionComplete;
    
    public Room[,] chickenDimensionRooms, swanDimensionRooms;
    public Dimension currentDimension;
    public Dimension[] dimensions = new Dimension[Enum.GetValues(typeof(Dimension.DimensionType)).Length - 1];
    [HideInInspector] public bool isChangingRoom = false;
    [HideInInspector] public bool dimensionChanged;
    public RoomChangeDirection roomChangeDirection = RoomChangeDirection.RELOAD;

    GameObject topDoor, bottomDoor, leftDoor, rightDoor;

    LevelGeneration levelGeneration;

    public enum RoomChangeDirection
    {
        RELOAD,
        UP,
        DOWN,
        LEFT,
        RIGHT
    }

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else if (instance != this)
        {
            Destroy(gameObject);
            return;
        }
        levelGeneration = GetComponent<LevelGeneration>();
        GenerateDimensions();
        GetUpdatedObjectReferences();
        EnableDoors();

        originalSpawnPoint = GameObject.Find("Spawn Point").transform;
        secondarySpawnPoint = GameObject.Find("Secondary Spawn Point").transform;
        ResetPlayerPosition();
        
    }

    private void Start()
    {
       
    }

    public void GetStartingRoom()
    {
        for (int x = 0; x < LevelGeneration.halfGridSizeX * 2; x++)
        {
            for (int y = 0; y < LevelGeneration.halfGridSizeY * 2; y++)
            {
                if (currentDimension.rooms[x, y] != null && currentDimension.rooms[x, y].originalType == Room.RoomType.STARTING_ROOM)
                {
                    startingRoom = currentDimension.rooms[x, y];
                    currentRoom = startingRoom;
                }
            }
        }
    }

    public void GenerateDimensions()
    {
        int numberOfDimensions = Enum.GetValues(typeof(Dimension.DimensionType)).Length;

        List<Dimension.DimensionType> dimensionTypes = new List<Dimension.DimensionType>();
        dimensionTypes.AddRange((Dimension.DimensionType[])Enum.GetValues(typeof(Dimension.DimensionType)));

        for (int i = 0; i < numberOfDimensions - 1; i++) // Minus 2 to account for DEFAULT
        {
            dimensions[i] = new Dimension
            {
                dimensionType = dimensionTypes[i + 1] // i + 1 to skip DEFAULT
            };

            levelGeneration.CreateRooms();
            dimensions[i].rooms = levelGeneration.rooms;
        }

        foreach(Dimension dimension in dimensions)
        {
            foreach(Room room in dimension.rooms)
            {
                if(room != null)
                {
                    levelGeneration.SetRoomScene(room, dimension);
                    levelGeneration.SetRoomDoors(dimension.rooms);
                }
            }
        }

    }

    void Update()
    {
        CheckForInput();
        CheckSceneLoadStatus();
    }

    void CheckSceneLoadStatus()
    {
        if (SceneLoader.finishedLoadingScene)
        {
            SceneLoader.finishedLoadingScene = false;
            GetUpdatedObjectReferences();
            EnableDoors();
            SetUpDoorScenes();
            SetSpawnPoints();
            GetComponent<PuzzleCompletionScript>().AddDoors();
            ResetPlayerPosition();
            levelGeneration.DrawMap();
        }
    }


    void ResetPlayerPosition()
    {
        if(currentRoom == null)
        {
            player.transform.position = originalSpawnPoint.position;
        }
        else
        {
            player.transform.position = currentRoom.isComplete ? secondarySpawnPoint.position : originalSpawnPoint.position;
        }
    }

    void GetUpdatedObjectReferences()
    {
       
        player = GameObject.Find("Player").transform;
        switch (roomChangeDirection)
        {
            case RoomChangeDirection.UP:
                currentRoom = currentDimension.rooms[(int)currentRoom.gridPos.x + LevelGeneration.halfGridSizeX, (int)currentRoom.gridPos.y + 1 + LevelGeneration.halfGridSizeY];
                break;
            case RoomChangeDirection.DOWN:
                currentRoom = currentDimension.rooms[(int)currentRoom.gridPos.x + LevelGeneration.halfGridSizeX, (int)currentRoom.gridPos.y - 1 + LevelGeneration.halfGridSizeY];
                break;
            case RoomChangeDirection.LEFT:
                currentRoom = currentDimension.rooms[(int)currentRoom.gridPos.x - 1 + LevelGeneration.halfGridSizeX, (int)currentRoom.gridPos.y + LevelGeneration.halfGridSizeY];
                break;
            case RoomChangeDirection.RIGHT:
                currentRoom = currentDimension.rooms[(int)currentRoom.gridPos.x + 1 + LevelGeneration.halfGridSizeX, (int)currentRoom.gridPos.y + LevelGeneration.halfGridSizeY];
                break;
            case RoomChangeDirection.RELOAD:
                break;
        }
        roomChangeDirection = RoomChangeDirection.RELOAD;

        if (currentRoom != null)
        {
            currentRoom.currentType = Room.RoomType.CURRENT_ROOM;
        }
        if (GameObject.Find("Level Exits") != null)
        {
            topDoor = GameObject.Find("Level Exits").transform.Find("Top Door").Find("Door Frame").Find("Door Entrance").gameObject;
            bottomDoor = GameObject.Find("Level Exits").transform.Find("Bottom Door").Find("Door Frame").Find("Door Entrance").gameObject;
            leftDoor = GameObject.Find("Level Exits").transform.Find("Left Door").Find("Door Frame").Find("Door Entrance").gameObject;
            rightDoor = GameObject.Find("Level Exits").transform.Find("Right Door").Find("Door Frame").Find("Door Entrance").gameObject;
        }
    }

    void CheckForInput()
    {
        if (Input.GetButtonDown("Reset"))
        {
            SceneLoader.sceneToLoad = SceneManager.GetActiveScene().name;
            SceneLoader.loadScene = true;
        }
        if (Input.GetKeyDown(KeyCode.I) && currentRoom.isComplete && topDoor.activeInHierarchy)
        {
            player.transform.position = topDoor.transform.position;
        }
        if (Input.GetKeyDown(KeyCode.K) && currentRoom.isComplete && bottomDoor.activeInHierarchy)
        {
            player.transform.position = bottomDoor.transform.position;
        }
        if (Input.GetKeyDown(KeyCode.J) && currentRoom.isComplete && leftDoor.activeInHierarchy)
        {
            player.transform.position = leftDoor.transform.position;
        }
        if (Input.GetKeyDown(KeyCode.L) && currentRoom.isComplete && rightDoor.activeInHierarchy)
        {
            player.transform.position = rightDoor.transform.position;
        }

    }

    void SetUpDoorScenes()
    {
        if(topDoor.activeInHierarchy)
        {
            topDoor.GetComponent<LoadTrigger>().sceneToLoad = currentRoom.topDoorScene;
        }
        if(bottomDoor.activeInHierarchy)
        {
            bottomDoor.GetComponent<LoadTrigger>().sceneToLoad = currentRoom.bottomDoorScene;
        }
        if (leftDoor.activeInHierarchy)
        {
            leftDoor.GetComponent<LoadTrigger>().sceneToLoad = currentRoom.leftDoorScene;
        }
        if (rightDoor.activeInHierarchy)
        {
            rightDoor.GetComponent<LoadTrigger>().sceneToLoad = currentRoom.rightDoorScene;
        }
    }

    void EnableDoors()
    {
        
        if (GameObject.Find("Level Exits") != null && currentRoom != null && currentRoom.doorTop)
        {
            GameObject.Find("Level Exits").transform.Find("Top Door").gameObject.SetActive(true);
        }
        if (GameObject.Find("Level Exits") != null && currentRoom != null && currentRoom.doorBot)
        {
            GameObject.Find("Level Exits").transform.Find("Bottom Door").gameObject.SetActive(true);
        }
        if (GameObject.Find("Level Exits") != null && currentRoom != null && currentRoom.doorLeft)
        {
            GameObject.Find("Level Exits").transform.Find("Left Door").gameObject.SetActive(true);
        }
        if (GameObject.Find("Level Exits") != null && currentRoom != null && currentRoom.doorRight)
        {
            GameObject.Find("Level Exits").transform.Find("Right Door").gameObject.SetActive(true);
        }
    }

    void SetSpawnPoints()
    {

        if (GameObject.Find("Spawn Point") != null)
        {
            originalSpawnPoint = GameObject.Find("Spawn Point").transform;
        }
        if (GameObject.Find("Secondary Spawn Point") != null)
        {
            if (topDoor != null && topDoor.activeInHierarchy)
            {
                secondarySpawnPoint = topDoor.transform;
            }
            else if (bottomDoor != null && bottomDoor.activeInHierarchy)
            {
                secondarySpawnPoint = bottomDoor.transform;
            }
            else if (leftDoor != null && leftDoor.activeInHierarchy)
            {
                secondarySpawnPoint = leftDoor.transform;
            }
            else if (rightDoor != null && rightDoor.activeInHierarchy)
            {
                secondarySpawnPoint = rightDoor.transform;
            }

        }
        if (currentRoom != null)
        {
            currentRoom.currentSpawnPoint = currentRoom.isComplete ? secondarySpawnPoint : originalSpawnPoint;
        }
    }

}
