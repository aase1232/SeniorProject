﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Dimension {

    public Room[,] rooms;
    public DimensionType dimensionType;
    public bool isComplete;

    public enum DimensionType
    {
        DEFAULT,
        CHICKEN,
        SWAN
    }

    public Dimension()
    {
        rooms = new Room[LevelGeneration.halfGridSizeX * 2, LevelGeneration.halfGridSizeY * 2];
    }

}
