﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RotateObject : MonoBehaviour {

    public Transform target; //Assign to the object you want to rotate
    Vector3 object_pos;
    public int rotationOffset;
    //private float x;
    //private Vector3 ls;
    private bool gunIsFacingRight, playerIsFacingRight;

    private GameObject rayGun, playerRig;
    private float startingMouseRotation;
    bool canFlipLeft, canFlipRight, flippedOnce;

    Transform body;
    private void Start()
    {
        //x = transform.localScale.x;
        //ls = transform.localScale;
        rayGun = GameObject.Find("RayGun");
        playerRig = GameObject.Find("PlayerRig");
        Transform body = playerRig.transform.Find("Body");

        Vector3 theScale = body.localScale;
        Vector3 difference = Camera.main.ScreenToWorldPoint(Input.mousePosition) - transform.position;
        difference.Normalize();

        startingMouseRotation = Mathf.Atan2(difference.y, difference.x) * Mathf.Rad2Deg;

    }

    void Update()
    {
        body = playerRig.transform.Find("Body");
        Vector3 difference = Camera.main.ScreenToWorldPoint(Input.mousePosition) - transform.position;
        difference.Normalize();

        float rotationZ = Mathf.Atan2(difference.y, difference.x) * Mathf.Rad2Deg;

        bool isArmFacingLeft = IsArmFacingLeft(rotationZ);
        if ((!IsArmFacingLeft(startingMouseRotation) && (body.localScale.x == 1f))
            || ((IsArmFacingLeft(startingMouseRotation) && (body.localScale.x == -1f)))
            && !flippedOnce)
        {
            flippedOnce = true;
            canFlipLeft = true;
        }
        if(((IsArmFacingLeft(startingMouseRotation) && !isArmFacingLeft)
            || (!IsArmFacingLeft(startingMouseRotation) && isArmFacingLeft))
            && !flippedOnce){
            flippedOnce = true;
            canFlipLeft = true;
        }


        //if (((startingMouseRotation < -90f || startingMouseRotation > 90f)
        //    && (rotationZ > -90f || rotationZ < 90))
        //    || ((startingMouseRotation > -90f || startingMouseRotation < 90f)
        //    && (rotationZ < -90f || rotationZ > 90))
        //    && !flippedOnce)
        //{
            
        //}
        print("can flip left " + canFlipLeft);
        print("can flip right " + canFlipRight);
        print("gun is facing left " + IsArmFacingLeft(rotationZ));
        
        transform.rotation = Quaternion.Euler(0f, 0f, rotationZ + rotationOffset);
        //print(Convert.ToInt32(rotationZ));

        //if (rotationZ < -90f || rotationZ > 90)
        //{
        //    gunIsFacingRight = false;
        //}
        //else
        //{
        //    gunIsFacingRight = true;
        //}

        
        if (IsArmFacingLeft(rotationZ)
            && canFlipLeft)
        {
                canFlipLeft = false;
                canFlipRight = true;
                Flip();
        }
        if(!IsArmFacingLeft(rotationZ)
            && canFlipRight)
        {
                canFlipRight = false;
                canFlipLeft = true;
                Flip();
        }

        

        //Vector3 mouse_pos = Input.mousePosition;
        //mouse_pos.z = 5.23f; //The distance between the camera and object
        //object_pos = Camera.main.WorldToScreenPoint(target.position);
        //mouse_pos.x = mouse_pos.x - object_pos.x;
        //mouse_pos.y = mouse_pos.y - object_pos.y;
        //angle = Mathf.Atan2(mouse_pos.y, mouse_pos.x) * Mathf.Rad2Deg;
        //target.rotation = Quaternion.Euler(new Vector3(0, 0, angle));
    }

    private bool IsArmFacingLeft(float rotation)
    {
        if ((rotation > 90f && rotation < 180f) || 
            (rotation < -90f && rotation > -180f)
)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    void Flip()
    {
        SpriteRenderer gunRenderer = rayGun.GetComponent<SpriteRenderer>();
        //gunRenderer.flipX = !gunRenderer.flipX;


        //GameObject playerBody = GameObject.Find("Body");
        //SpriteRenderer bodyRenderer = playerBody.GetComponent<SpriteRenderer>();
        //bodyRenderer.flipX = !bodyRenderer.flipX;



        Transform body = playerRig.transform.Find("Body");

        Vector3 theScale = body.localScale;
        theScale.x *= -1;
        body.localScale = theScale;

        playerIsFacingRight = body.localScale.x > 0;

        if (playerIsFacingRight)
        {
            gunRenderer.flipY = false;
            gunRenderer.flipX = false;
            
        }
        else
        {
            gunRenderer.flipY = true;
            gunRenderer.flipX = false;
        }
        
        //foreach (Transform bodyPart in body)
        //{
           
        //    SpriteRenderer bodyPartsRenderer = bodyPart.gameObject.GetComponent<SpriteRenderer>();
        //    bodyPartsRenderer.flipX = !bodyPartsRenderer.flipX;
            
        //}

    }
}
