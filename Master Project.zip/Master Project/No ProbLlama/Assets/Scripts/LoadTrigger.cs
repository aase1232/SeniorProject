﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LoadTrigger : MonoBehaviour {
    
    public string sceneToLoad;

    private void OnTriggerEnter2D(Collider2D collision)
    {

        if (collision.gameObject.tag == "Player" 
            && SceneLoader.loadScene == false
            && GunBehavior.isHeldByPlayer)
        {
            if (name == "Chicken Dimension Portal")
            {
                foreach(Dimension dimension in GameManager.instance.dimensions)
                {
                    if(dimension.dimensionType == Dimension.DimensionType.CHICKEN)
                    {
                        if (!dimension.isComplete)
                        {
                            GameManager.instance.currentDimension = dimension;
                        }
                        else
                        {
                            return;
                        }
                    }
                }
                GameManager.instance.GetStartingRoom();
                sceneToLoad = GameManager.instance.currentRoom.sceneForThisRoom;
            }
            else if (name == "Swan Dimension Portal")
            {
                foreach (Dimension dimension in GameManager.instance.dimensions)
                {
                    if (dimension.dimensionType == Dimension.DimensionType.SWAN)
                    {

                        if (!dimension.isComplete)
                        {
                            GameManager.instance.currentDimension = dimension;
                        }
                        else
                        {
                            return;
                        }
                    }
                }
                GameManager.instance.GetStartingRoom();
                sceneToLoad = GameManager.instance.currentRoom.sceneForThisRoom;
            }
            else if (transform.parent.parent != null && transform.parent.parent.name == "Top Door")
            {
                GameManager.instance.roomChangeDirection = GameManager.RoomChangeDirection.UP;
            }
            else if (transform.parent.parent != null && transform.parent.parent.name == "Bottom Door")
            {
                GameManager.instance.roomChangeDirection = GameManager.RoomChangeDirection.DOWN;
            }
            else if (transform.parent.parent != null && transform.parent.parent.name == "Left Door")
            {
                GameManager.instance.roomChangeDirection = GameManager.RoomChangeDirection.LEFT;
            }
            else if (transform.parent.parent != null && transform.parent.parent.name == "Right Door")
            {
                GameManager.instance.roomChangeDirection = GameManager.RoomChangeDirection.RIGHT;
            }
            if(GameManager.instance.currentRoom != null)
            {
                GameManager.instance.currentRoom.currentType = GameManager.instance.currentRoom.originalType;
            }
            if (!(name == "Door Entrance"))
            {
                SceneLoader.sceneToLoad = sceneToLoad;
                SceneLoader.loadScene = true;
            }
        }
    }
}
