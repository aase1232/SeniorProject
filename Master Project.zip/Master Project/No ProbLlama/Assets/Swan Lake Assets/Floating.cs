﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Floating : MonoBehaviour {

	private Rigidbody2D theLogBody;
	private bool dislodged;
	private bool isUnderwater;
	private bool passedBetweenWater;
	public int floatingSpeed;

	// Use this for initialization
	void Start () {
		dislodged = false;
		isUnderwater = false;
		passedBetweenWater = false;
		floatingSpeed = 10;
		theLogBody = GetComponent<Rigidbody2D> ();
	}
	
	// Update is called once per frame
	void Update () {
		if (dislodged == true && isUnderwater == true) {
			theLogBody.velocity = new Vector3 (0, floatingSpeed, 0);
		}
	}

	void OnCollisionEnter2D(Collision2D collisionInfo){
		if (collisionInfo.gameObject.tag == "Player") {
			dislodged = true;
		}
	}

	void OnCollisionExit2D(Collision2D collisionInfo) {
		if (collisionInfo.gameObject.tag == "Player") {
			dislodged = false;
		}
	}

	void OnTriggerEnter2D(Collider2D collisionInfo) {
		if (collisionInfo.gameObject.tag == "Water") {
			if (isUnderwater == true) {
				passedBetweenWater = true;
			} 
			else {
				isUnderwater = true;
			}
		}

	}

	void OnTriggerExit2D(Collider2D collisionInfo) {
		if (collisionInfo.gameObject.tag == "Water") {
			if (passedBetweenWater == true) {
				passedBetweenWater = false;
			}
			else {
				isUnderwater = false;
			}
		}
	}

}
