﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class swanAttack : MonoBehaviour {

	private Animator anim;
	public LayerMask playerLayer;
	public Collider2D[] overlapCircle; 
	public float radius;

	// Use this for initialization
	void Start () {
		anim = this.GetComponent<Animator> ();

	}

	// Update is called once per frame
	void Update () {
		overlapCircle = Physics2D.OverlapCircleAll(new Vector2(transform.position.x, transform.position.y), radius, playerLayer);
		if(overlapCircle.Length > 0){
			anim.SetBool ("attack", true);
		}
		else{
			anim.SetBool ("attack", false);
		}
	}
}
