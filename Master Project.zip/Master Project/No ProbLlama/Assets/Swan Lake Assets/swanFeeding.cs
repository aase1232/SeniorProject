﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class swanFeeding : MonoBehaviour {

	public bool isFeeding;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		if (isFeeding == true) {
			StopCoroutine(HealOverTime());
			StartCoroutine(HealOverTime());
		}
	}

	void OnCollisionStay2D(Collision2D collisionInfo)
	{
		if (collisionInfo.gameObject.tag == "Reed") {
			isFeeding = true;
			GetComponent<Breath> ().isUnderwater = false;
		}
	}

	void OnCollisionExit2D(Collision2D collisionInfo)
	{
		if (collisionInfo.gameObject.tag == "Reed") {
			isFeeding = false;
			GetComponent<Breath> ().isUnderwater = true;
		}
	}

	IEnumerator HealOverTime(){
		yield return new WaitForSeconds (2f);
			GetComponent<PlayerHealth>().heal(5);
	}

}
