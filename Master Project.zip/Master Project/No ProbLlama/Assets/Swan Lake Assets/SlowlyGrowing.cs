﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SlowlyGrowing : MonoBehaviour {

	//public GameObject bulletModel;
	//breath_out indicates how long until the player runs out of air
	public float grow_up;
	//breath_timer indicates how long the player has been underwater
	public float growing_timer;
	//private GameObject playerHealth;
	private bool isUnderwater;
	public GameObject reed;
	public ShrinkAndGrow shrinkAndGrow;

	// Use this for initialization
	void Start () {
		grow_up = 10f;
		growing_timer = 0f;
		isUnderwater = false;
	}
	
	// Update is called once per frame
	void Update () {
		if (isUnderwater == true) {
			StopCoroutine(GrowCountDown());
			StartCoroutine(GrowCountDown());
		}
	}

	void OnTriggerEnter2D(Collider2D collisionInfo) {
		if (collisionInfo.gameObject.tag == "Water") {
			isUnderwater = true;
		}

	}

	void OnTriggerExit2D(Collider2D collisionInfo) {
		if (collisionInfo.gameObject.tag == "Water") {
			growing_timer = 0f;
			isUnderwater = false;
		}
	}

	IEnumerator GrowCountDown(){
		yield return new WaitForSeconds (2f);
		growing_timer = growing_timer + Time.deltaTime;
		if (growing_timer >= grow_up
			&& !shrinkAndGrow.canOnlyShrink
			&& shrinkAndGrow.maxGrowHits > 0) {
			yield return new WaitForSeconds (10f);
			reed.transform.localScale *= shrinkAndGrow.growScale;
			shrinkAndGrow.maxGrowHits--;
			shrinkAndGrow.maxShrinkHits++;


		}
	}

}
