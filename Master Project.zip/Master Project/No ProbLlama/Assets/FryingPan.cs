﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FryingPan : MonoBehaviour {

	private bool firstHit =false;
	private Rigidbody2D rb;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		}

	void OnCollision(Collider other) {
		print ("On trigger");
		if (firstHit = false) {
			rb = GetComponent<Rigidbody2D>();
			rb.gravityScale.Equals (1);

		}
		firstHit = true;

	}
}
