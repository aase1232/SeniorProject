﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class YellowButton : MonoBehaviour {
	public GateManager gm;
	void OnTriggerEnter2D (Collider2D other)
	{
		if (other.tag == "Object" || other.tag =="Shootable") 
		{
			Destroy (this.gameObject);
			Destroy (other.gameObject);
			gm.OpenYellowGate();
		}
		if (other.tag == "Player")
		{
			gm.OpenYellowGate ();
			Destroy (this.gameObject);
		}
	}
}
