﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class SceneLoader : MonoBehaviour {

    public static string sceneToLoad;
   

    public GameObject loadingBarGameObject;
    public Slider loadingBarSlider;
    AsyncOperation async;
    public Text loadingText;
    public static bool finishedLoadingScene;
    public static bool loadScene = false;

    public static string currentScene;
    // Use this for initialization
    void Start()
    {
        currentScene = SceneManager.GetActiveScene().name;
        loadingBarGameObject.SetActive(false);
    }
    
	
	void Update () {
		if(loadScene == true)
        {
            loadScene = false;
            //StopCoroutine(ChangeScene(""));  //not sure if necessary
            print("loading");
            StartCoroutine(ChangeScene(sceneToLoad));

        }

	}

    IEnumerator ChangeScene(string sceneToLoad)
    {
        loadingBarGameObject.SetActive(true);
        float fadeTime = GameObject.Find("GameManager").GetComponent<Fading>().BeginFade(1);
        yield return new WaitForSeconds(fadeTime);
        async = SceneManager.LoadSceneAsync(sceneToLoad);
        async.allowSceneActivation = false;
        //async.allowSceneActivation = true;

        while (!async.isDone)
        {
            float progress = Mathf.Clamp01(async.progress / 0.9f);
            loadingBarSlider.transform.SetAsLastSibling();
            loadingBarSlider.value = progress;
            loadingText.text = progress * 100f + "%";
            if (progress == 1f)
            {
                loadingBarGameObject.SetActive(false);
                async.allowSceneActivation = true;
                finishedLoadingScene = true;
                if(GameObject.Find("Play") != null)
                {
                    GameObject.Find("Play").SetActive(false);
                }
                if(GameObject.Find("Quit") != null)
                {
                    GameObject.Find("Quit").SetActive(false);
                }
                if (GameObject.Find("No ProbLlama") != null)
                {
                    GameObject.Find("No ProbLlama").SetActive(false);
                }
                currentScene = sceneToLoad;
            }

            yield return null;
        }
    }
}
