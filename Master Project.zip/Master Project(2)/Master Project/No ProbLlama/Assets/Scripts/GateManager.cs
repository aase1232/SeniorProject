﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GateManager : MonoBehaviour {
	

	public int blackButtonPress = 0;
	public int whiteGateCount = 0;
	public GameObject whiteGate;
	public Transform WhiteGoal;
	public Transform notWhiteGoal;
	public bool isDone = false;
	public GameObject gm;

	void Awake ()
	{
		gm = GameObject.Find ("GameManager");
	}

	void Update ()
	{
		if (blackButtonPress == 4) 
		{
			openBlackGate ();
		}

		if (whiteGateCount == 8 && isDone == false) 
		{
			Debug.Log ("REACHED 8 COUNTS!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
			MoveGate(true);
		}

		if (whiteGateCount < 8 && isDone) 
		{
			MoveGate(false);
		}

	}
	public void pressBlackButton()
	{
		blackButtonPress += 1;
	}
	public void OpenBlueGate()
	{
		GameObject[] blues = GameObject.FindGameObjectsWithTag ("BlueGate");
		foreach (GameObject b in blues)
			Destroy (b.gameObject);
	}

	public void OpenOrangeGate()
	{
        GameObject[] oranges = GameObject.FindGameObjectsWithTag ("OrangeGate");
		foreach (GameObject o in oranges)
			Destroy (o.gameObject);
	}

	public void OpenYellowGate()
	{
        GameObject[] yellows = GameObject.FindGameObjectsWithTag ("YellowGate");
		foreach (GameObject y in yellows)
			Destroy (y.gameObject);
	}

	public void OpenGreenGate()
	{
        GameObject[] greens = GameObject.FindGameObjectsWithTag ("GreenGate");
		foreach (GameObject g in greens)
			Destroy (g.gameObject);
	}

	public void OpenRedGate()
	{
        GameObject[] reds = GameObject.FindGameObjectsWithTag ("RedGate");
		foreach (GameObject r in reds)
			Destroy (r.gameObject);
	}
		

	public void openBlackGate()
	{
		GameObject[] blacks = GameObject.FindGameObjectsWithTag ("BlackGate");
		foreach (GameObject b in blacks)
			Destroy (b.gameObject);
	}

	public void CountWhiteGate()
	{
		Debug.Log ("counting up for each hit");
		whiteGateCount += 1;
	}

	public void uncountWhiteGate()
	{
		Debug.Log ("counting down with each hit");
		whiteGateCount -= 1;
	}

	public void MoveGate(bool allPressed)
	{
		
		if (allPressed) {
			whiteGate.transform.position = WhiteGoal.transform.position;
			isDone = true;
			gm.GetComponent<PuzzleCompletionScript> ().isPuzzleCompleted = true;
		} 
		else
		{
			whiteGate.transform.position = notWhiteGoal.transform.position;
			isDone = false;
			gm.GetComponent<PuzzleCompletionScript> ().isPuzzleCompleted = false;
		}
	}
}
