﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LoadTrigger : MonoBehaviour {
    
    public string sceneToLoad;

    private void OnTriggerEnter2D(Collider2D collision)
    {

        if (collision.gameObject.tag == "Player" 
            && SceneLoader.loadScene == false
            && GameObject.Find("RayGun").GetComponent<GunBehavior>().isHeldByPlayer)
        {
            if (name == "Chicken Dimension Portal")
            {
                print("chicken");
                GameManager.instance.currentDimension = GameManager.Dimension.CHICKEN;
                GameManager.instance.GetStartingRoom();
                //sceneToLoad = GameManager.instance.currentRoom.sceneForThisRoom;
            }
            else if (name == "Swan Dimension Portal")
            {
                GameManager.instance.currentDimension = GameManager.Dimension.SWAN;
                GameManager.instance.GetStartingRoom();
                //sceneToLoad = GameManager.instance.currentRoom.sceneForThisRoom;
            }
            else if (transform.parent.parent != null && transform.parent.parent.name == "Top Door")
            {
                GameManager.instance.roomChangeDirection = GameManager.RoomChangeDirection.UP;
            }
            else if (transform.parent.parent != null && transform.parent.parent.name == "Bottom Door")
            {
                GameManager.instance.roomChangeDirection = GameManager.RoomChangeDirection.DOWN;
            }
            else if (transform.parent.parent != null && transform.parent.parent.name == "Left Door")
            {
                GameManager.instance.roomChangeDirection = GameManager.RoomChangeDirection.LEFT;
            }
            else if (transform.parent.parent != null && transform.parent.parent.name == "Right Door")
            {
                GameManager.instance.roomChangeDirection = GameManager.RoomChangeDirection.RIGHT;
            }
            if (!(name == "Door Entrance"))
            {
                if(GameManager.instance.currentRoom != null)
                {
                    sceneToLoad = GameManager.instance.currentRoom.sceneForThisRoom;
                }
                SceneLoader.sceneToLoad = sceneToLoad;
                SceneLoader.loadScene = true;
            }
        }
    }
}
