﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EndVolcano : MonoBehaviour {

	public GameObject lava;
	public GameObject chickens;
	private Animator anim;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	private void OnTriggerEnter2D(Collider2D collision)
	{
		if (collision.tag == "Egg") {
			print ("collison");
			Destroy (lava);

			anim = chickens.GetComponent<Animator> ();
			anim.SetBool ("complete", true);
		}
	}
}
