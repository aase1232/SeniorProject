﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShrinkAndGrow : MonoBehaviour {

    
    public bool canOnlyGrow, canOnlyShrink;
    public int maxGrowHits, maxShrinkHits;
    public float growScale, shrinkScale;
    public ScaleDirection direction;

    public enum ScaleDirection
    {
        ALL_DIRECTIONS,
        UPWARDS,
        DOWNWARDS,
        LEFT,
        RIGHT
    }

    private void Start()
    {
        Vector2 position = transform.localPosition;
        Vector2 parentPosition = Vector2.zero;

        if(transform.parent != null)
        {
            parentPosition = transform.parent.position;
            foreach(Transform child in transform.parent)
            {

            }

            switch (direction)
            {
                case ScaleDirection.UPWARDS:  //change pivot of object to be at the bottom
                    transform.parent.position = new Vector2(parentPosition.x, parentPosition.y - .5f);
                    transform.localPosition = new Vector2(transform.localPosition.x, transform.localPosition.y + 0.5f);
                    break;
                case ScaleDirection.DOWNWARDS:  //change pivot of object to be at the top
                    transform.position = new Vector2(transform.localPosition.x, -0.5f);
                    transform.parent.position = new Vector2(parentPosition.x, parentPosition.y + .5f);
                    break;
                case ScaleDirection.LEFT:  //change pivot of object to be to the right
                    transform.position = new Vector2(-0.5f, transform.localPosition.y);
                    transform.parent.position = new Vector2(parentPosition.x + 0.5f, parentPosition.y);
                    break;
                case ScaleDirection.RIGHT:  //change pivot of object to be to the left
                    transform.position = new Vector2(0.5f, transform.localPosition.y);
                    transform.parent.position = new Vector2(parentPosition.x - 0.5f, parentPosition.y);
                    break;
            }
        }
    }
}
