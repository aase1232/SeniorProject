﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RotateObject : MonoBehaviour {

    public Transform target; //Assign to the object you want to rotate
    Vector3 object_pos;
    public int rotationOffset;
    //private float x;
    //private Vector3 ls;
    private bool gunIsFacingRight, playerIsFacingRight;

    private GameObject rayGun, playerRig;
    private float startingMouseRotation;
    bool canFlipLeft, canFlipRight, flippedOnce;

    Transform body;
    private void Start()
    {
        //x = transform.localScale.x;
        //ls = transform.localScale;
        rayGun = GameObject.Find("RayGun");
        playerRig = GameObject.Find("PlayerRig");
        body = playerRig.transform.Find("Body");

        Vector3 theScale = body.localScale;
        Vector3 difference = Camera.main.ScreenToWorldPoint(Input.mousePosition) - transform.position;
        difference.Normalize();

        startingMouseRotation = Mathf.Atan2(difference.y, difference.x) * Mathf.Rad2Deg;

    }

    void Update()
    {
        Vector3 difference = Camera.main.ScreenToWorldPoint(Input.mousePosition) - transform.position;
        difference.Normalize();

        float rotationZ = Mathf.Atan2(difference.y, difference.x) * Mathf.Rad2Deg;

        bool isArmFacingLeft = IsArmFacingLeft(rotationZ);
        if ((!IsArmFacingLeft(startingMouseRotation) && (body.localScale.x == 1f))
            || ((IsArmFacingLeft(startingMouseRotation) && (body.localScale.x == -1f)))
            && !flippedOnce)
        {

            flippedOnce = true;
            Flip();
        }


        //if (((startingMouseRotation < -90f || startingMouseRotation > 90f)
        //    && (rotationZ > -90f || rotationZ < 90))
        //    || ((startingMouseRotation > -90f || startingMouseRotation < 90f)
        //    && (rotationZ < -90f || rotationZ > 90))
        //    && !flippedOnce)
        //{

        //}

        transform.rotation = Quaternion.Euler(0f, 0f, rotationZ + rotationOffset);
        //print(Convert.ToInt32(rotationZ));

        //if (rotationZ < -90f || rotationZ > 90)
        //{
        //    gunIsFacingRight = false;
        //}
        //else
        //{
        //    gunIsFacingRight = true;
        //}

        
        if (IsArmFacingLeft(rotationZ)
            && body.localScale.x == 1f)
        {
                Flip();
        }
        if(!IsArmFacingLeft(rotationZ)
            && body.localScale.x == -1f)
        {

            Flip();
        }
        
    }

    private bool IsArmFacingLeft(float rotation)
    {
        if ((rotation > 90f && rotation < 180f) || 
            (rotation < -90f && rotation > -180f)
)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    void Flip()
    {
        SpriteRenderer gunRenderer = rayGun.GetComponent<SpriteRenderer>();

        

        Transform body = playerRig.transform.Find("Body");

        Vector3 theScale = body.localScale;
        theScale.x *= -1;
        body.localScale = theScale;

        playerIsFacingRight = body.localScale.x > 0;

        if (playerIsFacingRight && GunBehavior.isHeldByPlayer)
        {
            gunRenderer.flipY = !gunRenderer.flipY;
            //gunRenderer.flipY = true;
            //gunRenderer.flipX = true;
        }
        else if(!playerIsFacingRight && GunBehavior.isHeldByPlayer)
        {

            gunRenderer.flipY = !gunRenderer.flipY;
            //gunRenderer.flipY = false;
            //gunRenderer.flipX = true;
        }
        
        //foreach (Transform bodyPart in body)
        //{
           
        //    SpriteRenderer bodyPartsRenderer = bodyPart.gameObject.GetComponent<SpriteRenderer>();
        //    bodyPartsRenderer.flipX = !bodyPartsRenderer.flipX;
            
        //}

    }
}
