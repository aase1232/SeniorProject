﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MapSpriteSelector : MonoBehaviour {
	
	
    public bool up, down, left, right;
	public Room.RoomType type; // 0: normal, 1: enter
	public Color normalRoomColor, startingRoomColor, bossRoomColor;
    private Transform roomTransform;
    private GameObject room;
    SpriteRenderer rend;
    Color mainColor;

    void Start () {
        print("map");
        mainColor = normalRoomColor;
        //roomTransform = transform.Find("Room Sprite");
        //rend = roomTransform.GetComponent<SpriteRenderer>();
		PickSprite();
		//PickColor();
	}
	void PickSprite(){ //picks correct sprite based on the four door bools
        if (up)
        {
            GameObject upDoor = roomTransform.Find("Top Door").gameObject;
            upDoor.SetActive(true);
        }
        if (down)
        {
            GameObject downDoor = roomTransform.Find("Bottom Door").gameObject;
            downDoor.SetActive(true);
        }
        if (right)
        {
            GameObject rightDoor = roomTransform.Find("Right Door").gameObject;
            rightDoor.SetActive(true);
        }
        if (left)
        {
            GameObject leftDoor = roomTransform.Find("Left Door").gameObject;
            leftDoor.SetActive(true);
        }
    }

  //  void PickColor(){ //changes color based on what type the room is
  //      //Color mainColor = normalRoomColor;
  //      switch (type)
  //      {
  //          case Room.RoomType.RANDOM_PUZZLE:
  //              mainColor = normalRoomColor;
  //              break;
  //          case Room.RoomType.STARTING_ROOM:
  //              mainColor = startingRoomColor;
  //              break;
  //          case Room.RoomType.BOSS_ROOM:
  //              mainColor = bossRoomColor;
  //              break;
  //      }
		//rend.color = mainColor;
	//}

    
}