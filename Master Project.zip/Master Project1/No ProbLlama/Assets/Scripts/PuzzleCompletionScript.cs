﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PuzzleCompletionScript : MonoBehaviour
{

	public bool isPuzzleCompleted;

	private List<GameObject> doors;

    private void Start()
    {
        doors = new List<GameObject>();
        SetDoors();
    }
    void Update ()
	{
        if (GameManager.instance.isChangingRoom)
        {
            SetDoors();
        }

		if (isPuzzleCompleted)
        {
            GameManager.instance.currentRoom.isComplete = true;

			foreach (GameObject door in doors) {
				door.transform.Find("Door Frame").GetComponent<SpriteRenderer>().color = Color.blue;
			}
		}
	}

    void SetDoors()
    {
        doors.Clear();

        if (GameObject.Find("Top Door") != null)
        {
            doors.Add(GameObject.Find("Top Door"));
        }
        if (GameObject.Find("Bottom Door") != null)
        {
            doors.Add(GameObject.Find("Bottom Door"));
        }
        if (GameObject.Find("Left Door") != null)
        {
            doors.Add(GameObject.Find("Left Door"));
        }
        if (GameObject.Find("Right Door") != null)
        {
            doors.Add(GameObject.Find("Right Door"));
        }
    }
}
