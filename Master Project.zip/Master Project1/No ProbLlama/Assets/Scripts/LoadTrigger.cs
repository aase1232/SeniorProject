﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LoadTrigger : MonoBehaviour {
    
    public string sceneToLoad;

    private void OnTriggerEnter2D(Collider2D collision)
    {

        if (collision.gameObject.tag == "Player" && SceneLoader.loadScene == false)
        {
            collision.gameObject.GetComponent<Rigidbody2D>().isKinematic = true;  //Might not work properly!!!!!
            SceneLoader.loadScene = true;
            SceneLoader.sceneToLoad = sceneToLoad;
            if(name == "Top Door")
            {
                GameManager.instance.roomChangeDirection = GameManager.RoomChangeDirection.UP;
            }
            else if(name == "Bottom Door")
            {
                GameManager.instance.roomChangeDirection = GameManager.RoomChangeDirection.DOWN;
            }
            else if(name == "Left Door")
            {
                GameManager.instance.roomChangeDirection = GameManager.RoomChangeDirection.LEFT;
            }
            else if(name == "Right Door")
            {
                GameManager.instance.roomChangeDirection = GameManager.RoomChangeDirection.RIGHT;
            }
            else if(name == "Chicken Dimension Portal")
            {
                GameManager.instance.currentDimension = GameManager.Dimension.CHICKEN;
            }
            else if(name == "Swan Dimension Portal")
            {
                GameManager.instance.currentDimension = GameManager.Dimension.SWAN;
            }
        }

    }


}
