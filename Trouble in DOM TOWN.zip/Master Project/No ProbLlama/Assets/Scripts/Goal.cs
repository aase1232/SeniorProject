﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Goal : MonoBehaviour
{
    public string triggerTag;
	GameObject gameManager;

	void Awake ()
	{
		gameManager = GameObject.Find ("GameManager");
	}

	void OnTriggerEnter2D (Collider2D other)
	{
		if (other.tag == triggerTag) {
            Destroy(gameObject);
			gameManager.GetComponent<PuzzleCompletionScript> ().isPuzzleCompleted = true;
		}
	}
}
	
